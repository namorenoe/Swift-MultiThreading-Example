//
//  ViewController.swift
//  Multi-Threading
//
//  Created by IOSDeveloper on 1/11/20.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        
    }

    @IBAction func handleTap(_ sender: Any) {
        DispatchQueue.global(qos: .background).async {
            for i in 0...5{
                print(":)\(i)")
            }
        }
        DispatchQueue.global(qos: .userInteractive).async {
            for i in 0...5{
                print(":(\(i)")
            }
        }
        
    }
    
    @IBAction func handleTap2(_ sender: Any) {
        DispatchQueue.global(qos: .background).sync {
            for i in 0...5{
                print(":)\(i)")
            }
        }
        DispatchQueue.global(qos: .userInteractive).async {
            for i in 0...5{
                print(":(\(i)")
            }
        }
        
    }

    
}

